//#include <iostream>
//using namespace std;
//
//int main()
//{
//    int r;
//    cin >> r;
//    for (int i = 1; i <= r; i++)
//    {
//        for (int j = r, k = r; j >= 1; j--)
//        {
//            if (j > i)
//            {
//                cout << k << " ";
//                k--;
//            }
//            else
//            {
//                cout << k << " ";
//            }
//        }
//        cout << endl;
//    }
//}