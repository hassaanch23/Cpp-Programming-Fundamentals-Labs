//#include <iostream>
//using namespace std;
//int main()
//{
//	string Welcome, Name, Roll, Degree, Section, Lab;
//	Welcome = 
//	Name = "Muhammad Hassaan";
//	Roll = "22L-7919";
//	Degree = "BS(SE)";
//	Section = "A";
//	Lab = "CS-06";
//
//	cout << "\tWelcome to Programming Fundamentals\n";
//	cout << "\t\tName: " << Name << endl;
//	cout << "\t\t  Roll#: " << Roll << endl;
//	cout << "\t\t   Degree: " << Degree << endl;
//	cout << "\t\t    Section: " << Section << endl;
//	cout << "\t\t    Lab: " << Lab << endl;
//
//
//	
//	return 0;
//
//	
//
//
//
//}