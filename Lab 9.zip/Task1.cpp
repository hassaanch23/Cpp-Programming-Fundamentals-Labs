//#include <iostream>
//using namespace std;
//void Array(int Array1[],int Array2[]) {
//	for (int i = 0; i < 10; i++) {
//		cout << "Enter a Number for Index " << i << ": ";
//		cin >> Array1[i];
//	}
//	for (int j = 0; j < 10; j++) {
//		int i = j;
//		Array2[j] = Array1[i];
//		i++;
//	}
//	for (int j = 0; j < 10; j++)
//	{
//		Array2[j] = Array1[j] * Array1[j];
//	}
//	cout << "Array1\tArray2\n";
//	for (int i = 0, j = 0; i < 10; i++, j++) {
//		j < 10;
//		cout << Array1[i] << "\t" << Array2[j] << endl;
//	}
//}
//int main() {
//
//	int Array1[10] = { 0 };
//	int Array2[10] = { 0 };
//	Array(Array1, Array2);
//
//}
