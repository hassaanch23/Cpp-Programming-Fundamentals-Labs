//#include <iostream>
//using namespace std;
//void frequency_check(int Array[]) {
//	int Key, Count = 0;
//	for (int i = 0; i <10; i++) {
//		cout << "Enter a Number for Index " << i << ": ";
//		cin >> Array[i];
//	}
//	cout << "\nEnter Key for printing Frequency: ";
//	cin >> Key;
//	for (int i = 0; i < 10; i++) {
//		if (Array[i] == Key)
//			Count++;
//	}
//	cout << "The Frequency of the Key " << Key << " is " << Count << endl;
//}
//int main() {
//	int array[10];
//	frequency_check(array);
//
//}