//#include <iostream>
//#include <cstdlib>
//#include <ctime>
//using namespace std;
//int main()
//{
//	int Dice1, Dice2,Sum, Product;
//	srand(time(0));
//	for (int i = 1; i <= 10; i++) {
//		Dice1 = (int)(rand() % 6 + 1);
//		Dice2 = (int)(rand() % 6 + 1);
//		Sum = Dice1 + Dice2;
//		Product = Dice1 * Dice2;
//		cout << "Sum of Dices= " << Sum << endl;
//		cout << "Product of Dices= " << Product << endl;
//	}
//	cout << endl;
//}