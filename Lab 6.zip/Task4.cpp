//#include <iostream>
//using namespace std;
//int main()
//{
//	double X, Y, Power = 1.0;
//	cout << "Enter the number:\n";
//	cin >> X;
//	cout << "What power you want to take?\n";
//	cin >> Y;
//	if (Y > 0)
//		for (int i = 1; i <= Y; i++) {
//			Power = Power * X;
//		}
//	else if (Y < 0) {
//		float Power1=1;
//		for (int i = 1; -i >= Y; i++) {
//			Power1 = Power1 * X;
//			Power = 1 / Power1;
//		}
//	}
//	else if (Y == 0) {
//		Power = 1;
//	}
//	cout << "\nThe Result of " << X << "^" << Y << " is " << Power;
//	return 0;
//}