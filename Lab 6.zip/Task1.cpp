//#include <iostream>
//using namespace std;
//void main()
//{
//    int Number, x = 1;
//    bool Triangular = 0;
//    cin >> Number;
//
//    for (int n = 2; n <= Number; n++) {
//        if (x + n == Number) {
//            cout << "It is Triangular" << endl;;
//            Triangular = 1;
//        }
//        x += n;
//    }
//    if (!Triangular) {
//        cout << "It is not Triangular";
//    }
//}