//#include <iostream>
//using namespace std;
//int main() {
//	int X, Y, Rem = 1, X1, X2, Y2;
//	cout << "Enter two Positive Numbers:\n";
//	cin >> X >> Y;
//	X2 = X;
//	Y2 = Y;
//	if (X < Y) {
//		X1 = X;
//		X = Y;
//		Y = X1;
//	}
//	cout << endl;
//	while (1) {
//		Rem = X % Y;
//		X = Y;
//		Y = Rem;
//		if (Rem == 0) {
//			cout << "GDC (" << X1 << "," << Y2 << ") =" << X;
//			break;
//		}
//	}
//}