//#include <iostream>
//using namespace std;
//double getLength()
//{
//	double a;
//	cout << "What is the Length of Rectangle: ";
//	cin >> a;
//	return a;
//}
//double getWidth() {
//	double a;
//	cout << "What is the width of Rectangle: ";
//	cin >> a;
//	return a;
//}
//double getArea(double length, double width) {
//	int Area = length * width;
//	return Area;
//}
//void displayData(double length, double width, double Area) {
//	cout << "The Area of rectangle with length " << length << " and width " << width << " = " << Area << endl;
//	cout << "--------------------------------------------------------------------";
//}
//
//int main() {
//	double width, length, Area;
//	length=getLength();
//	width=getWidth();
//	Area= getArea(length, width);
//
//	displayData(length, width, Area);
//}