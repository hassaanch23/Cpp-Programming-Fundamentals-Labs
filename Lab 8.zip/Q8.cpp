//#include <iostream>
//using namespace std;
//int main()
//{
//	static int Index[5];
//	for (int Number = 0; Number < 5; Number++) {
//		cout << "Enter values for Index " << Number << ": ";
//		cin >> Index[Number];
//		cout << endl;
//	}
//	for (int Number = 0; Number < 5; Number++) {
//		cout << "The Values Stored in Index " << Number << ": " << Index[Number];
//		cout << endl;
//	}
//}