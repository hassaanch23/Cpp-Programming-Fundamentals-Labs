//#include <iostream>
//using namespace std;
//
//void CalculateRetail(float a, float b) {
//		float c = a * (b / 100);
//		float Retail = a + c;
//		cout << "The Item Retail Price is: " << Retail << endl;
//		cout << "***********************************************";
//}
//int main() {
//	float ItemWholesale, MarkupPer;
//
//	cout << "What is the Item Wholesale cost: ";
//	cin >> ItemWholesale;
//	cout << "What is its Markup Percentage: ";
//	cin >> MarkupPer;
//
//	if (ItemWholesale > 0 && MarkupPer > 0) {
//		CalculateRetail(ItemWholesale, MarkupPer);
//	}
//	else {
//		cout << "Enter the values in Positive.";
//		return 0;
//	}
//
//}