//#include <iostream>
//using namespace std;
//
//unsigned long Factorial(long a,unsigned long &Fac) {
//	for (int i = 1; i <= a; i++) {
//		Fac = Fac * i;
//	}
//	return Fac;
//}
//int main()
//{
//	unsigned long Number, Fac = 1;
//	cout << "Enter a Number: ";
//	cin >> Number;
//	cout <<"The Factorial of "<<Number<<" is "<< Factorial(Number, Fac) << endl;
//	cout << "-----------------------------";
//}