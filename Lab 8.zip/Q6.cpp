//#include <iostream>
//using namespace std;
//
//void SwapbyValue(int x, int y) {
//	cout << "          SWAPPING BY VALUES\n";
//	cout << "Before Swapping X=" << x << "\t Y=" << y << endl;
//	int z = x;
//	x = y;
//	y = z;
//	cout << "After Swapping X=" << x << "\t Y=" << y << endl;
//}
//void Swapbyreferance(int& x, int& y, int& z) {
//	cout << "\n          SWAPPING BY REFERANCE\n";
//	cout << "Before Swapping X=" << x << "\t Y=" << y << endl;
//	z = x;
//	x = y;
//	y = z;
//}
//int main()
//{
//	int x, y, z = 0;
//	cout << "Enter two Numbers: ";
//	cin >> x >> y;
//	SwapbyValue(x, y);
//	Swapbyreferance(x, y, z);
//
//	cout << "After Swapping X=" << x << "\t Y=" << y << endl;
//}