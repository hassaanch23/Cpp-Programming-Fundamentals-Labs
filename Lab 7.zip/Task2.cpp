//#include <iostream>
//using namespace std;
//int main() {
//
//	int N1, N2;
//	cout << "Enter two Numbers:\n";
//	cin >> N1 >> N2;
//
//	cout << "Before Swapping the value of X and Y: " << N1 << "," << N2 << endl;
//	
//	N1 = N1 + N2;
//	N2 = N1 - N2;
//	N1 = N1 - N2;
//	
//	cout << "After Swapping the value of X and Y: " << N1 << "," << N2 << endl;
//}