//#include <iostream>
//using namespace std;
//int main()
//{
//	int Number, Check = 0;
//	cout << "Enter a Number: ";
//	cin >> Number;
//	for (int N = 1; N <= Number; N++) {
//		for (int i = 2; i < N; i++) {
//			if (N % i == 0) {
//				Check++;
//				break;
//			}
//		}if (Check == 0 && N != 1)
//			cout << N << " ";
//		Check = 0;
//	}
//	cout << endl;
//	return 0;
//}