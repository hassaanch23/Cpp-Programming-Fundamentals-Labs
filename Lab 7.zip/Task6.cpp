//#include <iostream>
//#include<iomanip>
//using namespace std;
//int main() {
//	int Number, Product, A;
//	cout << "Enter a Number: ";
//	cin >> Number;
//
//	for (int i = 1; i <= Number; i++) {
//		cout << i << "*\t";
//		for (int j = 1; j <= Number; j++) {
//			Product = i * j;
//			cout << setw(4)<< Product;
//		}
//		cout << endl;
//	}
//}