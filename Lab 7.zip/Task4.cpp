//#include <iostream>
//#include <iomanip>
//using namespace std;
//int main()
//{
//	int Number;
//	cout << "Enter a Number: ";
//	cin >> Number;
//	int spaces = Number;
//	spaces--;
//	for (int i = 1; i <= Number; i++) {
//		for (int j = 1; j <= spaces; j++)
//			cout << setw(3) << " ";
//		spaces--;
//		int N1 = 1;
//		for (int k = 1; k <= i; k++) {
//			cout << setw(3) << N1 << setw(3)<< " ";
//
//			N1 = N1 * (i - k) / k;
//		}
//		cout << endl;
//	}
//}