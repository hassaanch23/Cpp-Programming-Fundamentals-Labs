//#include <iostream>
//using namespace std;
//int main()
//{
//	float a, b, number, positive, negative, P1, P2, P3, Zero;
//	cout << "Numbers you want to enter:\n";
//	cin >> b;
//	cout << "Enter numbers:\n";
//	a = 0;
//	positive = 0;
//	negative = 0;
//	Zero = 0;
//
//	while (a<b)
//	{
//		cin>>number;
//		if (number > 0)
//			positive++;
//		else if (number == 0)
//			Zero++;
//		else if (number < 0)
//			negative++;
//		a++;
//	}
//	P1 = positive / b * 100;
//	P2 = negative / b * 100;
//	P3 = Zero / b * 100;
//
//	cout << "Percentage of Positive Number is: " << P1 << endl;
//	cout << "Percentage of Negative Number is: " << P2 << endl;
//	cout << "Percentage of Zeros is: " << P3 << endl;
//
//	return 0;
//
//}