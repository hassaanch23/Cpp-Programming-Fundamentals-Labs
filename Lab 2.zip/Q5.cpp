//#include <iostream>
//using namespace std;
//int main()
//{
//	int Number;
//	Number = 0;
//	while (Number <=98) {
//		Number = Number + 1;
//		cout << Number << endl;
//		Number = Number + 1;
//		cout << Number << "Tea" << endl;
//	}
//}