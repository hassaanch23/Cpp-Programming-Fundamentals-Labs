//#include <iostream>
//using namespace std;
//int main()
//{
//	int Year, February,a,b,c;
//
//	cout << "Enter the Year:\n";
//	cin >> Year;
//
//	a = Year % 4;
//	b = a % 100;
//	c = b % 400;
//
//	if (Year % 4 == 0) {
//		a % 100 == 0;
//		b % 400 == 0;
//		February = 29;
//	}
//	else if (Year % 4 == 0) {
//		February = 29;
//	}
//	else
//		February = 28;
//
//	cout << "There are 31 Days in January.\n";
//	cout << "There are " << February << " Days in Fabruary.\n";
//	cout << "There are 31 Days in March.\n";
//	cout << "There are 30 Days in April.\n";
//	cout << "There are 31 Days in May.\n";
//	cout << "There are 30 Days in June.\n";
//	cout << "There are 31 Days in July.\n";
//	cout << "There are 31 Days in August.\n";
//	cout << "There are 30 Days in September.\n";
//	cout << "There are 31 Days in October.\n";
//	cout << "There are 30 Days in November.\n";
//	cout << "There are 31 Days in December.\n";
//
//	if (February == 29)
//		cout << "It is a Leap Year";
//	else
//		cout << "It is Not a Leap Year";
//	return 0;
//}