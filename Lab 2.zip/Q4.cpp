//#include <iostream>
//using namespace std;
//int main()
//{
//	int a, b, c;
//	cout << "Enter any three variables:\n";
//	cin >> a >> b >> c;
//
//	if (a > 0) {
//		if (b % a == 0 && c % a == 0)
//			cout << "a is a common divisor";
//		else
//			cout << "a is not a common divisor";
//	}
//	else
//		return 0;
//	return 0;
//}