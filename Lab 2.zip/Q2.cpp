//#include <iostream>
//using namespace std;
//int main()
//{
//	int n, a;
//		cout << "Plese Enter a number:\n";
//	cin >> n;
//
//	if (n > 0) {
//		cout << "The Number is Positive\n";
//		if (n % 2 == 0)
//			cout << "The Number is Even\n";
//		else
//			cout << "The Number is Odd\n";
//	}
//	else if (n == 0)
//		cout << "It is even number.";
//	else
//		cout << "Negative";
//	return 0;
//}