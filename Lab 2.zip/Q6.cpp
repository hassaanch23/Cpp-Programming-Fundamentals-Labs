//#include <iostream>
//using namespace std;
//int main()
//{
//	int Number = 0, previous_num, repeat = 1, repetition;
//
//	cout << "Enter a number:\n";
//	cin >> Number;
//
//	previous_num = Number;
//	while (Number != -1) {
//		cout << "Enter a number";
//		cin >> Number;
//		if (Number == previous_num) {
//			repeat = repeat + 1;
//			repetition = Number;
//		}
//		previous_num = Number;
//	}
//	if (repeat == 3) {
//		cout << "Yess!! " << repetition << " was repeated 3 times.";
//	}
//	else
//		cout << "Not any value repeated 3 times";
//}