//#include <iostream>
//using namespace std;
//int main()
//{
//	int a, b, c, d, e;
//	float Item1 = 12.95, Item2 = 24.95, Item3 = 6.95, Item4 = 14.95, Item5 = 3.95, Price, SalesTax, TotalPrice;
//
//	cout << "Price of Item 1\t= Rs.12.95\n";
//	cout << "Price of Item 2\t= Rs.24.95\n";
//	cout << "Price of Item 3\t= Rs.6.95\n";
//	cout << "Price of Item 4\t= Rs.14.95\n";
//	cout << "Price of Item 5\t= Rs.3.95\n";
//
//	cout << "What quantity of Items you want to buy?\n";
//	cout << "Item 1: ";
//	cin >> a;
//	cout << "Item 2: ";
//	cin >> b;
//	cout << "Item 3: ";
//	cin >> c;
//	cout << "Item 4: ";
//	cin >> d;
//	cout << "Item 5: ";
//	cin >> e;
//
//	Price = Item1 * a + Item2 * b + Item3 * c + Item4 * d + Item5 * e;
//	SalesTax = Price * 0.06;
//	TotalPrice = Price + SalesTax;
//
//	cout << "Price= " << Price << "Rs\n";
//	cout << "Sales Tax= " << SalesTax << "Rs\n";
//	cout << "Total Price= " << TotalPrice << "Rs\n";
//
//	return 0;
//}