//#include <iostream>
//using namespace std;
//
//int Counter(char greet[], int X) {
//	int Counter = 0;
//	int j = 0;
//	for (int i = 0; greet[i] != '\0'; i++) {
//		if (int(greet[i] == 32)) {
//			Counter++;
//		}
//		j++;
//	}
//	j = j - Counter;
//	return j;
//}
//int main()
//{
//	char greet[100];
//	cout << "Enter any Sentence: ";
//	cin.getline(greet, 100);
//
//	cout << "Total Characters in the given array are: " << Counter(greet, 100);
//	cout << endl;
//	return 0;
//}