//#include<iostream>
//using namespace std;
//int main()
//{
//	char arr[100];
//	cout << "Enter the sentence: " << endl;
//	cin.getline(arr, 100);
//
//
//	char a;
//	int i = 0;
//	cout << "Enter the character: " << endl;
//	cin >> a;
//	while (arr[i] != '\0') {
//		if (arr[i] == a) {
//			cout << arr[i + 1];
//			i++;
//		}
//		else {
//			cout << arr[i];
//
//		}
//
//		i++;
//	}
//	return 0;
//}