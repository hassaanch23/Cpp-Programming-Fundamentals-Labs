//#include<iostream>
//
//using namespace std;
//int main()
//{
//	char arr[100];
//	cout << "Enter the sentence: " << endl;
//	cin.getline(arr, 100);
//
//	int i = 0, s = 0, t = 0;
//	while (arr[i] != '\0') {
//		if (arr[i] == ' ' || arr[i] == '\0') {
//			for (int a = i; a >= t; a--) {
//
//				cout << arr[a];
//			}
//			t = i + 1;
//		}
//		i++;
//	}
//	cout << char(32);
//	for (int a = i; a >= t; a--) {
//
//		cout << arr[a];
//	}
//	return 0;
//}
